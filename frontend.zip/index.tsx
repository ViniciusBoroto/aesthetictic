import DashboardPage from "./app/page"

export default DashboardPage
