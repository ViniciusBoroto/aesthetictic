import DashboardPage from "./page"

export default DashboardPage
